function u = Control_Input()
% Parameters
K_att = 1;
K_rep = 1;
D_obs = 0.5;
rho_0 =0.2;
for i=1:size(x_APF,1)
    x=x_APF(i,:).';
    F_att=K_att*(x-Goal_position);
    if norm(x-Obstacle1_center)>norm(x-Obstacle2_center)
        Obstacle_center=Obstacle2_center;
    else
        Obstacle_center=Obstacle1_center;
    end
    rho_x = norm(x-Obstacle_center) -D_obs;
    % Repulsive Potential Field and Force
    if rho_x>rho_0
        U_rep=0;
    else
        U_rep=1/2*K_rep*(1/rho_x-1/rho_0)^2;
    end
    
    if rho_x>rho_0
        F_rep=[0,0].';
    else
        F_rep=-K_rep/(rho_x^2)*(1/rho_x-1/rho_0)*(x-Obstacle_center)/norm(x-Obstacle_center);
        %     F_rep=K_rep/(rho_x^2)*(1/rho_x-1/rho_0)*(x-Obstacle_center)/rho_x;
    end
    u(i,:)=-F_att-F_rep;
end
end

