clear
clc
%% Load Data
load x_Nom
x_Nom=x_APF;
load x_APF_01
x_APF_01=x_APF;
load x_APF_05
x_APF_05=x_APF;
load x_SF_01
x_SF_01=x_APF;
load x_SF_05
x_SF_05=x_APF;

%% Define global parameters
global Initial_position Goal_position Obstacle1_center Obstacle2_center Obstacle3_center
Initial_position(:,1)=[3,5].';
Goal_position(:,1)=[0,0].';
Obstacle1_center=[1,1.5].';
Obstacle2_center=[2.5,3].';
Obstacle3_center=[4,4.2].';

%% Draw two obstacles
radius =0.5;
% Define the circle equation
theta = linspace(0, 2*pi, 100);
Obs1_x= Obstacle1_center(1) + radius*cos(theta);
Obs1_y= Obstacle1_center(2) + radius*sin(theta);
Obs2_x= Obstacle2_center(1) + radius*cos(theta);
Obs2_y= Obstacle2_center(2) + radius*sin(theta);
Obs3_x= Obstacle3_center(1) + radius*cos(theta);
Obs3_y= Obstacle3_center(2) + radius*sin(theta);

figure(1)
% Initial position and goal position
h1=plot(Initial_position(1), Initial_position(2), 'r.', 'MarkerSize', 35, 'MarkerFaceColor', 'r');
hold on
h2=plot(Goal_position(1), Goal_position(2), 'bp', 'MarkerSize', 15, 'MarkerFaceColor', 'b');
h3=plot(x_Nom(:,1), x_Nom(:,2), 'k--', 'LineWidth', 2, 'MarkerSize', 15, 'MarkerFaceColor', 'k');
h4=plot(x_SF_05(:,1), x_SF_05(:,2), 'b-', 'LineWidth', 2, 'MarkerSize', 15, 'MarkerFaceColor', 'b');
h5=plot(x_APF_05(:,1), x_APF_05(:,2), 'm--', 'LineWidth', 2, 'MarkerSize', 15, 'MarkerFaceColor', 'm');

% Obstacles
fill(Obs1_x, Obs1_y, 'red', 'FaceAlpha', 0.3, 'EdgeColor', 'red');  % 'red' for fill and boundary color
fill(Obs2_x, Obs2_y, 'red', 'FaceAlpha', 0.3, 'EdgeColor', 'red');  % 'red' for fill and boundary color
fill(Obs3_x, Obs3_y, 'red', 'FaceAlpha', 0.3, 'EdgeColor', 'red');  % 'red' for fill and boundary color
plot(Obstacle1_center(1),Obstacle1_center(2),'k.','MarkerSize',15)
plot(Obstacle2_center(1),Obstacle2_center(2),'k.','MarkerSize',15)
plot(Obstacle3_center(1),Obstacle3_center(2),'k.','MarkerSize',15)
text(Obstacle1_center(1)-0.33, Obstacle1_center(2)-0.25, 'Obs. 1', 'FontSize', 20, 'Color', 'k','interpreter','latex');
text(Obstacle2_center(1)-0.33, Obstacle2_center(2)-0.25, 'Obs. 2', 'FontSize', 20, 'Color', 'k','interpreter','latex');
text(Obstacle3_center(1)-0.33, Obstacle3_center(2)-0.25, 'Obs. 3', 'FontSize', 20, 'Color', 'k','interpreter','latex');
set(gca,'FontSize',28)
set(gcf,'Position',[200,200,1000,725], 'color','w')
legend([h1,h2,h3,h4,h5],'Initial Position','Goal Position',...
               'Nominal Control $\mathbf{u}_{\mathrm{nom}}$',...
               '$\rho_{0}=0.5$ with $\mathbf{u}_{\mathrm{AC}}$',...
               '$\rho_{0}=0.5$ with $\mathbf{u}_{\mathrm{APF-AC}}$','interpreter','latex','Location','northwest');
axis equal
grid on

figure(2)
% Initial position and goal position
h1=plot(Initial_position(1), Initial_position(2), 'r.', 'MarkerSize', 35, 'MarkerFaceColor', 'r');
hold on
h2=plot(Goal_position(1), Goal_position(2), 'bp', 'MarkerSize', 15, 'MarkerFaceColor', 'b');
% Plot Trajectory
h3=plot(x_Nom(:,1), x_Nom(:,2), 'k--', 'LineWidth', 2, 'MarkerSize', 15, 'MarkerFaceColor', 'k');
h4=plot(x_SF_01(:,1), x_SF_01(:,2), 'b-', 'LineWidth', 2, 'MarkerSize', 15, 'MarkerFaceColor', 'b');
h5=plot(x_APF_01(:,1), x_APF_01(:,2), 'm--', 'LineWidth', 2, 'MarkerSize', 15, 'MarkerFaceColor', 'm');
% Obstacles
fill(Obs1_x, Obs1_y, 'red', 'FaceAlpha', 0.3, 'EdgeColor', 'red');  % 'red' for fill and boundary color
fill(Obs2_x, Obs2_y, 'red', 'FaceAlpha', 0.3, 'EdgeColor', 'red');  % 'red' for fill and boundary color
fill(Obs3_x, Obs3_y, 'red', 'FaceAlpha', 0.3, 'EdgeColor', 'red');  % 'red' for fill and boundary color
plot(Obstacle1_center(1),Obstacle1_center(2),'k.','MarkerSize',15)
plot(Obstacle2_center(1),Obstacle2_center(2),'k.','MarkerSize',15)
plot(Obstacle3_center(1),Obstacle3_center(2),'k.','MarkerSize',15)
text(Obstacle1_center(1)-0.33, Obstacle1_center(2)-0.25, 'Obs. 1', 'FontSize', 20, 'Color', 'k','interpreter','latex');
text(Obstacle2_center(1)-0.33, Obstacle2_center(2)-0.25, 'Obs. 2', 'FontSize', 20, 'Color', 'k','interpreter','latex');
text(Obstacle3_center(1)-0.33, Obstacle3_center(2)-0.25, 'Obs. 3', 'FontSize', 20, 'Color', 'k','interpreter','latex');
set(gca,'FontSize',28)
set(gcf,'Position',[200,200,1000,725], 'color','w')
legend([h1,h2,h3,h4,h5],'Initial Position','Goal Position',...
               'Nominal Control $\mathbf{u}_{\mathrm{nom}}$',...
               '$\rho_{0}=0.1$ with $\mathbf{u}_{\mathrm{AC}}$',...
               '$\rho_{0}=0.1$ with $\mathbf{u}_{\mathrm{APF-AC}}$','interpreter','latex','Location','northwest');
axis equal
grid on


%% Compute the control input
% u_APF_01= Control_Input_APF(x_APF_01);
% u_SF_01= Control_Input_SF(x_APF_01);
u_APF_05= Control_Input_APF(x_APF_05);
u_SF_05= Control_Input_SF(x_APF_05);

figure(3)
plot(vecnorm(u_SF_05(1:800,:).'), 'b-', 'LineWidth', 2, 'MarkerSize', 15, 'MarkerFaceColor', 'b');
hold on
plot(vecnorm(u_APF_05(1:800,:).'), 'm--', 'LineWidth', 2, 'MarkerSize', 15, 'MarkerFaceColor', 'm');


% figure(4)
% plot(vecnorm(u_SF_01(1:200,:).'), 'b-', 'LineWidth', 2, 'MarkerSize', 15, 'MarkerFaceColor', 'b');
% hold on
% plot(vecnorm(u_APF_01(1:200,:).'), 'm--', 'LineWidth', 2, 'MarkerSize', 15, 'MarkerFaceColor', 'm');



